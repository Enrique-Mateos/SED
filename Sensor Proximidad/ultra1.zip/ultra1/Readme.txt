El pin PD14 es el pin Trigger del sensor,el PE9 es el Echo del sensor ,el sensor se alimenta a 5 v
En el pin de Echo se a configurado con el timer1 en "Input Capture" con Polarity Selection en la opci�n de "Both Edges"
El timer4 esta para enviar un PWM de d=10 microsegundos con un T=60ms pero he optado por realizar el pulso de forma mas rudimentaria con un bucle if y Delay 
por lo que el TIM4 no se utiliza.
El ADC TAMPOCO SE UTILIZA.